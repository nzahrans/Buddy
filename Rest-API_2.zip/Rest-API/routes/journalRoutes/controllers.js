const { Storage } = require("@google-cloud/storage");
const storage = new Storage();
const bucketName = "capstonestorage1";
const bucket = storage.bucket(bucketName);
const language = require("@google-cloud/language");
const languageClient = new language.LanguageServiceClient();

// Create new journal entry
const createJournalEntry = async (req, res) => {
  try {
    const { userId, content, title } = req.body;

    // Analyze sentiment
    const sentiment = await analyzeSentiment(content);

    const journalEntry = {
      userId,
      title,
      content,
      sentiment,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Save journal entry to Google Cloud Storage as JSON file
    const fileName = `journal_${userId}_${Date.now()}.json`; // Unique for each entry
    const file = bucket.file(fileName);

    // Upload journal entry data as JSON to Google Cloud Storage
    await file.save(JSON.stringify(journalEntry), {
      contentType: "application/json",
    });

    res.status(201).json({
      fileName,
      journalEntry,
      message: "Journal entry created successfully",
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all journal entries for a user
const getJournalEntries = async (req, res) => {
  try {
    const { userId } = req.params;

    // List files in GCS for the given userId
    const [files] = await bucket.getFiles({ prefix: `journal_${userId}` });

    const entries = [];
    for (const file of files) {
      const [content] = await file.download();
      const journalEntry = JSON.parse(content.toString());
      entries.push({
        fileName: file.name,
        ...journalEntry,
      });
    }

    res.status(200).json({ entries });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get specific journal entry
const getJournalEntry = async (req, res) => {
  try {
    const { id } = req.params;

    // Retrieve the file from GCS with the specified ID
    const file = bucket.file(id);
    const [exists] = await file.exists();

    if (!exists) {
      return res.status(404).json({ message: "Journal entry not found" });
    }

    const [content] = await file.download();
    const journalEntry = JSON.parse(content.toString());

    res.status(200).json({
      fileName: id,
      ...journalEntry,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update journal entry
const updateJournalEntry = async (req, res) => {
  try {
    const { id } = req.params;
    const { content, title } = req.body;

    // Re-analyze sentiment if content is changed
    const sentiment = content ? await analyzeSentiment(content) : undefined;

    const updateData = {
      ...(title && { title }),
      ...(content && { content, sentiment }),
      updatedAt: new Date().toISOString(),
    };

    // Update the file in Google Cloud Storage
    const file = bucket.file(id);
    const [exists] = await file.exists();

    if (!exists) {
      return res.status(404).json({ message: "Journal entry not found" });
    }

    await file.save(
      JSON.stringify({ ...updateData, userId: req.body.userId }),
      {
        contentType: "application/json",
      }
    );

    res.status(200).json({
      message: "Journal entry updated successfully",
      sentiment,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete journal entry
const deleteJournalEntry = async (req, res) => {
  try {
    const { id } = req.params;

    // Delete the file from Google Cloud Storage
    const file = bucket.file(id);
    const [exists] = await file.exists();

    if (!exists) {
      return res.status(404).json({ message: "Journal entry not found" });
    }

    await file.delete();

    res.status(200).json({ message: "Journal entry deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Analyze journal mood
const analyzeJournalMood = async (req, res) => {
  try {
    const { content } = req.body;
    const sentiment = await analyzeSentiment(content);
    res.status(200).json({ sentiment });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Helper function to analyze sentiment using Google Cloud Natural Language API
async function analyzeSentiment(text) {
  const document = {
    content: text,
    type: "PLAIN_TEXT",
  };

  const [result] = await languageClient.analyzeSentiment({ document });
  const sentiment = result.documentSentiment;

  return {
    score: sentiment.score,
    magnitude: sentiment.magnitude,
    mood: interpretMood(sentiment.score),
  };
}

// Helper function to interpret sentiment score
function interpretMood(score) {
  const moods = {
    veryPositive: {
      threshold: 0.5,
      label: "Very Positive",
      emoji: "😊",
      advice: "Keep up the great energy!",
    },
    positive: {
      threshold: 0.1,
      label: "Positive",
      emoji: "🙂",
      advice: "You're doing well!",
    },
    neutral: {
      threshold: -0.1,
      label: "Neutral",
      emoji: "😐",
      advice: "Consider what might lift your spirits.",
    },
    negative: {
      threshold: -0.5,
      label: "Negative",
      emoji: "😔",
      advice: "Consider talking to someone about your feelings.",
    },
    veryNegative: {
      threshold: -Infinity,
      label: "Very Negative",
      emoji: "😢",
      advice: "Please reach out for support - you're not alone.",
    },
  };

  for (const mood of Object.values(moods)) {
    if (score >= mood.threshold) {
      return {
        label: mood.label,
        emoji: mood.emoji,
        advice: mood.advice,
        score: score,
      };
    }
  }
}

module.exports = {
  createJournalEntry,
  getJournalEntries,
  getJournalEntry,
  updateJournalEntry,
  deleteJournalEntry,
  analyzeJournalMood,
};
