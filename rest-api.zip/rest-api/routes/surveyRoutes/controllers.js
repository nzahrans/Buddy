const { Storage } = require("@google-cloud/storage");
const admin = require("firebase-admin");
const storage = new Storage(); // Inisialisasi GCS client
const bucketName = "capstonestorage1"; // Ganti dengan nama bucket GCS kamu
const bucket = storage.bucket(bucketName);

// Validation middleware
const validateToken = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split("Bearer ")[1];
    if (!token) throw new Error("No token provided");

    const decodedToken = await admin.auth().verifyIdToken(token);
    req.user = decodedToken;
    next();
  } catch (error) {
    res.status(401).json({ error: "Unauthorized" });
  }
};

// Get all survey questions (menyimpan pertanyaan ke file JSON di GCS)
const getSurveyQuestions = async (req, res) => {
  try {
    const file = bucket.file("survey_questions.json");
    const [exists] = await file.exists();

    if (!exists) {
      return res.status(404).json({ error: "Survey questions not found" });
    }

    const [contents] = await file.download();
    const questions = JSON.parse(contents);

    res.status(200).json({ questions });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Submit survey answers (menyimpan hasil survei ke GCS)
const submitSurveyAnswers = async (req, res) => {
  try {
    const { userId, answers } = req.body;

    // Calculate mental health score based on answers
    const score = calculateMentalHealthScore(answers);

    // Menyimpan hasil survei ke file JSON di GCS
    const file = bucket.file(`survey_responses/${userId}_survey_response.json`);
    const response = {
      userId,
      answers,
      score,
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
    };

    await file.save(JSON.stringify(response), { resumable: false });

    res.status(200).json({
      message: "Survey submitted successfully",
      score,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get survey results (ambil hasil survei berdasarkan userId)
const getSurveyResults = async (req, res) => {
  try {
    const { userId } = req.params;
    const file = bucket.file(`survey_responses/${userId}_survey_response.json`);
    const [exists] = await file.exists();

    if (!exists) {
      return res.status(404).json({ error: "Survey results not found" });
    }

    const [contents] = await file.download();
    const result = JSON.parse(contents);

    res.status(200).json({ results: [result] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Create new survey (admin only) - menyimpan pertanyaan ke GCS
const createSurvey = async (req, res) => {
  try {
    const { questions } = req.body;

    // Simpan pertanyaan survei ke file JSON di GCS
    const file = bucket.file("survey_questions.json");
    await file.save(JSON.stringify(questions), { resumable: false });

    res.status(200).json({ message: "Survey created successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Helper function to calculate mental health score
const calculateMentalHealthScore = (answers) => {
  let anxietyScore = 0;
  let depressionScore = 0;
  let stressScore = 0;
  let ptsdScore = 0;
  let socialAnxietyScore = 0;

  answers.forEach((answer) => {
    switch (answer.category) {
      case "anxiety":
        anxietyScore += parseInt(answer.score);
        break;
      case "depression":
        depressionScore += parseInt(answer.score);
        break;
      case "stress":
        stressScore += parseInt(answer.score);
        break;
      case "ptsd":
        ptsdScore += parseInt(answer.score);
        break;
      case "social_anxiety":
        socialAnxietyScore += parseInt(answer.score);
        break;
    }
  });

  const recommendations = generateRecommendations(
    anxietyScore,
    depressionScore,
    stressScore,
    ptsdScore,
    socialAnxietyScore
  );

  return {
    overall:
      (anxietyScore +
        depressionScore +
        stressScore +
        ptsdScore +
        socialAnxietyScore) /
      5,
    categories: {
      anxiety: anxietyScore,
      depression: depressionScore,
      stress: stressScore,
      ptsd: ptsdScore,
      social_anxiety: socialAnxietyScore,
    },
    severity: calculateSeverityLevel(
      anxietyScore,
      depressionScore,
      stressScore,
      ptsdScore,
      socialAnxietyScore
    ),
    recommendations: recommendations,
  };
};

const calculateSeverityLevel = (anxiety, depression, stress) => {
  const avgScore = (anxiety + depression + stress) / 3;
  if (avgScore <= 25) return "Normal";
  if (avgScore <= 50) return "Mild";
  if (avgScore <= 75) return "Moderate";
  return "Severe";
};

const generateRecommendations = (
  anxiety,
  depression,
  stress,
  ptsd,
  socialAnxiety
) => {
  const recommendations = [];

  if (anxiety > 50) {
    recommendations.push({
      type: "anxiety",
      activities: [
        "Latihan pernapasan dalam",
        "Meditasi mindfulness",
        "Konsultasi dengan psikolog spesialis anxiety",
      ],
    });
  }

  if (depression > 50) {
    recommendations.push({
      type: "depression",
      activities: [
        "Olahraga ringan secara rutin",
        "Terapi cahaya",
        "Konsultasi dengan psikiater",
      ],
    });
  }

  if (stress > 50) {
    recommendations.push({
      type: "stress",
      activities: ["Yoga", "Journaling", "Time management workshop"],
    });
  }

  if (ptsd > 50) {
    recommendations.push({
      type: "ptsd",
      activities: [
        "EMDR therapy",
        "Support group therapy",
        "Trauma-focused CBT",
      ],
    });
  }

  if (socialAnxiety > 50) {
    recommendations.push({
      type: "social_anxiety",
      activities: [
        "Exposure therapy",
        "Social skills training",
        "Group therapy sessions",
      ],
    });
  }

  return recommendations;
};

module.exports = {
  getSurveyQuestions,
  submitSurveyAnswers,
  getSurveyResults,
  createSurvey,
  validateToken,
};
